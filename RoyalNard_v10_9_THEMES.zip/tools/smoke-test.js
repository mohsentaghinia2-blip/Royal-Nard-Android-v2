const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
const script=html.split('<script>')[1].split('</script>')[0];
const start=script.indexOf("const W=1000,H=700,STORE=");
const end=script.indexOf('function tell(');
const core=script.slice(start,end);
const test=`
${core}
function count(pos,p){return pos.reduce((n,v)=>n+(own(v,p)?Math.abs(v):0),0)}
const s=initial();
assert.equal(count(s.p,0),15,'white initial checker count');
assert.equal(count(s.p,1),15,'dark initial checker count');
assert.equal(s.bar[0]+s.bar[1],0);
// Correct oversized bear-off: a checker farther toward the exit blocks an oversized die.
let p=Array(24).fill(0);p[3]=1;
assert.equal(canBear(p,[0,0],0,3,6),true,'white may overshoot when no farther checker exists');
p[1]=1;
assert.equal(canBear(p,[0,0],0,3,6),false,'white may not overshoot while a checker is farther ahead');
assert.equal(canBear(p,[0,0],0,1,6),true,'white may bear off the farthest checker');
p=Array(24).fill(0);p[20]=-1;
assert.equal(canBear(p,[0,0],1,20,6),true,'dark may overshoot when no farther checker exists');
p[22]=-1;
assert.equal(canBear(p,[0,0],1,20,6),false,'dark may not overshoot while a checker is farther ahead');
assert.equal(canBear(p,[0,0],1,22,6),true,'dark may bear off the farthest checker');
// A checker on the bar must enter before any other checker can move.
p=Array(24).fill(0);p[5]=1;p[12]=1;
let ms=getMoves(p,[1,0],0,1);
assert(ms.every(m=>m.from==='bar'),'bar entry is mandatory');
// Blocked point cannot be entered; a blot can be hit.
p=Array(24).fill(0);p[11]=1;p[10]=-2;
assert.equal(getMoves(p,[0,0],0,1).some(m=>m.from===11&&m.to===10),false,'blocked point rejected');
p[10]=-1;
assert.equal(getMoves(p,[0,0],0,1).some(m=>m.from===11&&m.to===10),true,'blot can be hit');
let r=applyMove(p,[0,0],[0,0],0,{from:11,to:10,d:1});
assert.equal(r.bar[1],1,'hit checker moves to bar');
assert.equal(r.p[10],1,'moving checker occupies hit point');
// Highest die must be used when only one of two dice can be played.
state={p:Array(24).fill(0),bar:[0,0],off:[0,0],player:0,dice:[1,6],rolled:true,over:false};state.p[10]=15;state.p[4]=-2;state.p[3]=-2;recalc();assert(legal.length>0&&legal.every(plan=>plan.seq.length===1&&plan.seq[0].d===1),'only playable die is retained');
state={p:Array(24).fill(0),bar:[0,0],off:[0,0],player:0,dice:[1,6],rolled:true,over:false};state.p[10]=15;state.p[9]=-2;state.p[3]=-2;recalc();assert(legal.length>0&&legal.every(plan=>plan.seq.length===1&&plan.seq[0].d===6),'higher die is required when only it can be played');
// Doubles provide four playable dice.
state={p:Array(24).fill(0),bar:[0,0],off:[0,0],player:0,dice:[2,2,2,2],rolled:true,over:false};state.p[10]=15;recalc();assert.equal(Math.max(...legal.map(plan=>plan.seq.length)),4,'double permits four moves');
// Bearing off is unavailable until every checker is in home and bar is empty.
p=Array(24).fill(0);p[3]=1;p[8]=1;
assert.equal(canBear(p,[0,0],0,3,6),false,'bearing off blocked by checker outside home');
p[8]=0;
assert.equal(canBear(p,[1,0],0,3,6),false,'bearing off blocked by checker on bar');
console.log('PASS: setup, 15 checkers each, bearing-off both directions, bar priority, blocked points, hits, bearing-off eligibility, higher-die priority, doubles, visible feedback, match reset control');
`;
vm.runInNewContext(test,{console,Math,JSON,Array,Set,assert});
assert(html.includes('#toast.show{opacity:1}'),'user-visible game feedback is present');
assert(html.includes('resetMatchButton'),'new match reset control is present');
